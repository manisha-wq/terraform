﻿# terraform-course

Course available on Udemy: https://www.udemy.com/course/deploy-infra-in-the-cloud-using-terraform/ 

<img src="https://github.com/HoussemDellai/terraform-course/blob/main/terraform_course.png?raw=true"/>
